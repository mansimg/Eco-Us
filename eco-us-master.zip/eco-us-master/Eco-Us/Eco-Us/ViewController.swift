//
//  ViewController.swift
//  Eco-Us
//
//  Created by Mansi Gandhi on 1/26/19.
//  Copyright © 2019 Mansi Gandhi. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    @IBAction func buttonClicked(_ sender: UIButton) {
        print("You finished!")
    }


}

